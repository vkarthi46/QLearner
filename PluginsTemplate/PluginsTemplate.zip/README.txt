The Examples folder contains ready-to-use plugins for the QLearner program.  Open QLearner and browse to one of the .dll files directly inside the Examples folder to use them.  The folders within the Examples folder are the projects/source code used to create the plugins.

The PluginTemplate folder contains a template project to guide you through making your own custom plugins and QStates.

The Documentation folder contains the class interfaces you implement to create your plugins, as well as a reference of all the functions available to your use.